﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace simple
{

    public class A {
        public int b=1;
    }

    class B {
         public int c=2;
    }
    
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
