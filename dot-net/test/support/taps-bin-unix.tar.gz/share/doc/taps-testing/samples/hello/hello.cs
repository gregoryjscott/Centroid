using Taps;

class HelloTest: TAP {

    static int Main() {
        Ok(true,"Hello, world");
        return 0;
    }
    
}
